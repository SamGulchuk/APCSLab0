class Main {
  public static void main(String[] args) 
  {
    double Euro = 0.85;
    double TwoEuro = 1.70;
    double Dollar = 1.18;
    double TwoDollar = 2.36;

    System.out.println("1 US dollar is " + Euro + " Euros");
    System.out.println("2 US dollars are " + TwoEuro + " Euros");
    System.out.println("1 Euro is " + Dollar + " US Dollars");
    System.out.println("2 Euros are " + TwoDollar + " US Dollars");
  }
}